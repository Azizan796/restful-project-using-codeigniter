<?php
// extends class Model
class PersonM extends CI_Model{
// response jika field ada yang kosong
  public function empty_response(){
    $response['status']=502;
    $response['error']=true;
    $response['message']='Field cannot blank';
    return $response;
  }
// function untuk insert data ke tabel tb_phone
  public function add_person($model,$price,$colour,$RAM){
if(empty($model) || empty($price) || empty($colour)|| empty($RAM)){
      return $this->empty_response();
    }else{
      $data = array(
        "model"=>$model,
        "price"=>$price,
        "colour"=>$colour,
        "RAM"=>$RAM,
      );
$insert = $this->db->insert("tb_phone", $data);
if($insert){
        $response['status']=200;
        $response['error']=false;
        $response['message']='Data person are add.';
        return $response;
      }else{
        $response['status']=502;
        $response['error']=true;
        $response['message']='Data person fail to add.';
        return $response;
      }
    }
}
// mengambil semua data person
  public function all_person(){
$all = $this->db->get("tb_phone")->result();
    $response['status']=200;
    $response['error']=false;
    $response['person']=$all;
    return $response;
}
// hapus data person
  public function delete_person($id){
if($id == ''){
      return $this->empty_response();
    }else{
      $where = array(
        "id"=>$id
      );
$this->db->where($where);
      $delete = $this->db->delete("tb_phone");
      if($delete){
        $response['status']=200;
        $response['error']=false;
        $response['message']='Data person delete.';
        return $response;
      }else{
        $response['status']=502;
        $response['error']=true;
        $response['message']='Data person fail to delete.';
        return $response;
      }
    }
}
// update person
  public function update_person($id,$model,$price,$colour,$RAM){
if($id == '' || empty($model) || empty($price) || empty($colour)|| empty($RAM)){
      return $this->empty_response();
    }else{
      $where = array(
        "id"=>$id
      );
$set = array(
        "model"=>$model,
        "price"=>$price,
        "colour"=>$colour,
        "RAM"=>$RAM,
      );
$this->db->where($where);
      $update = $this->db->update("tb_phone",$set);
      if($update){
        $response['status']=200;
        $response['error']=false;
        $response['message']='Data person were edit.';
        return $response;
      }else{
        $response['status']=502;
        $response['error']=true;
        $response['message']='Data person fail to edit.';
        return $response;
      }
    }
}
}
?>